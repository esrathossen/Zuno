// =========================================================
// sound_games.cpp - piezo buzzer mood sound effects, Tic Tac Toe
// game logic (played on the OLED, app is just the controller).
// =========================================================
#include "globals.h"

// ---------------- BUZZER (mood sound effects) ----------------
// Queues up to 4 short notes to play back-to-back without blocking the
// main loop() - see handleBuzzer(), called every loop iteration.
void queueSound(const SoundStep* steps, int len) {
  if (len > 4) len = 4;
  for (int i = 0; i < len; i++) soundQueue[i] = steps[i];
  soundQueueLen = len;
  soundStepIndex = 0;
  tone(BUZZER_PIN, soundQueue[0].freq);
  soundStepUntil = millis() + soundQueue[0].durationMs;
}

void handleBuzzer() {
  if (soundStepIndex < 0) return; // nothing queued
  if (millis() < soundStepUntil) return;

  soundStepIndex++;
  if (soundStepIndex >= soundQueueLen) {
    noTone(BUZZER_PIN);
    soundStepIndex = -1;
    return;
  }
  tone(BUZZER_PIN, soundQueue[soundStepIndex].freq);
  soundStepUntil = millis() + soundQueue[soundStepIndex].durationMs;
}

// Small chirp/beep per expression, triggered once whenever the face
// actually changes (see loop()) - not on every redraw.
void playFaceSound(FaceType f) {
  static const SoundStep happy[]     = { {1200, 80}, {1600, 100} };
  static const SoundStep sad[]       = { {500, 150}, {300, 200} };
  static const SoundStep angry[]     = { {200, 120}, {150, 120} };
  static const SoundStep love[]      = { {1400, 70}, {1800, 70}, {2200, 100} };
  static const SoundStep surprised[] = { {2000, 60}, {2400, 90} };
  static const SoundStep sleep[]     = { {400, 200} };

  switch (f) {
    case FACE_HAPPY:     queueSound(happy, 2);     break;
    case FACE_SAD:       queueSound(sad, 2);       break;
    case FACE_ANGRY:     queueSound(angry, 2);     break;
    case FACE_LOVE:      queueSound(love, 3);      break;
    case FACE_SURPRISED: queueSound(surprised, 2); break;
    case FACE_SLEEP:     queueSound(sleep, 1);     break;
    default: break; // Normal/Blink stay silent
  }
}

// ---------------- TIC TAC TOE (played on the OLED, app is the controller) ----------------
const int TTT_LINES[8][3] = {{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};

// Returns 'X', 'O', 'D' (draw), or 0 (game still going).
char tttCheckWinner() {
  for (int i = 0; i < 8; i++) {
    char a = tttBoard[TTT_LINES[i][0]], b = tttBoard[TTT_LINES[i][1]], c = tttBoard[TTT_LINES[i][2]];
    if (a != ' ' && a == b && b == c) return a;
  }
  for (int i = 0; i < 9; i++) if (tttBoard[i] == ' ') return 0;
  return 'D';
}

  return 'D';
}

// Simple heuristic AI for 'O': win if possible, else block 'X', else
// center, else a random corner, else any random empty cell.
int tttAiMove() {
  for (int i = 0; i < 8; i++) {
    int oCount = 0, emptyIdx = -1;
    for (int j = 0; j < 3; j++) {
      int cell = TTT_LINES[i][j];
      if (tttBoard[cell] == 'O') oCount++;
      else if (tttBoard[cell] == ' ') emptyIdx = cell;
    }
    if (oCount == 2 && emptyIdx != -1) return emptyIdx;
  }
  for (int i = 0; i < 8; i++) {
    int xCount = 0, emptyIdx = -1;
    for (int j = 0; j < 3; j++) {
      int cell = TTT_LINES[i][j];
      if (tttBoard[cell] == 'X') xCount++;
      else if (tttBoard[cell] == ' ') emptyIdx = cell;
    }
    if (xCount == 2 && emptyIdx != -1) return emptyIdx;
  }
  if (tttBoard[4] == ' ') return 4;
  int corners[4] = {0, 2, 6, 8}, avail[4], n = 0;
  for (int i = 0; i < 4; i++) if (tttBoard[corners[i]] == ' ') avail[n++] = corners[i];
  if (n > 0) return avail[random(0, n)];
  int empty[9], m = 0;
  for (int i = 0; i < 9; i++) if (tttBoard[i] == ' ') empty[m++] = i;
  return (m > 0) ? empty[random(0, m)] : -1;
}

// Renders the 3x3 board on the OLED - takes over the whole screen while
// a game is active (see tttActive in loop()).
void drawTttBoard() {
  display.clearDisplay();
  display.setTextColor(SH110X_WHITE);
  display.setTextSize(1);

  display.setCursor(2, 0);
  if (tttResult == "player")     display.print("YOU WIN!");
  else if (tttResult == "robot") display.print("ZUNO WINS");
  else if (tttResult == "draw")  display.print("DRAW");
  else display.print(tttPlayerTurn ? "YOUR TURN" : "ZUNO'S TURN");
  drawWifiIcon(wifiConnected);

  int gx = 34, gy = 14, cw = 20, ch = 17;
  display.drawFastVLine(gx + cw, gy, ch * 3, SH110X_WHITE);
  display.drawFastVLine(gx + cw * 2, gy, ch * 3, SH110X_WHITE);
  display.drawFastHLine(gx, gy + ch, cw * 3, SH110X_WHITE);
  display.drawFastHLine(gx, gy + ch * 2, cw * 3, SH110X_WHITE);

  for (int i = 0; i < 9; i++) {
    int row = i / 3, col = i % 3;
    int cx = gx + col * cw + cw / 2;
    int cy = gy + row * ch + ch / 2;
    if (tttBoard[i] == 'X') {
      display.drawLine(cx - 6, cy - 6, cx + 6, cy + 6, SH110X_WHITE);
      display.drawLine(cx - 6, cy + 6, cx + 6, cy - 6, SH110X_WHITE);
    } else if (tttBoard[i] == 'O') {
      display.drawCircle(cx, cy, 7, SH110X_WHITE);
    }
  }
  display.display();
}

void handleTttStart() {
  addCORS();
  memset(tttBoard, ' ', 9);
  tttPlayerTurn = true;
  tttResult = "";
  tttActive = true;
  currentMode = MODE_STILL; // safety: no driving while a game is on screen
  stopCar();
  drawTttBoard();
  server.send(200, "application/json", "{\"ok\":true,\"message\":\"Game started - your move\"}");
}

void handleTttMove() {
  addCORS();
  if (!tttActive) {
    server.send(400, "application/json", "{\"ok\":false,\"message\":\"Start a game first\"}");
    return;
  }
  if (!server.hasArg("plain")) {
    server.send(400, "application/json", "{\"ok\":false,\"message\":\"No body\"}");
    return;
  }
  StaticJsonDocument<128> doc;
  if (deserializeJson(doc, server.arg("plain"))) {
    server.send(400, "application/json", "{\"ok\":false,\"message\":\"Bad JSON\"}");
    return;
  }
  int cell = doc["cell"] | -1;

  String msg;
  if (tttResult != "") {
    msg = "Game over - start a new game";
  } else if (!tttPlayerTurn) {
    msg = "Not your turn";
  } else if (cell < 0 || cell > 8 || tttBoard[cell] != ' ') {
    msg = "Invalid move";
  } else {
    tttBoard[cell] = 'X';
    char w = tttCheckWinner();
    if (w == 'X') {
      tttResult = "player";
      playFaceSound(FACE_HAPPY);
    } else if (w == 'D') {
      tttResult = "draw";
    } else {
      tttPlayerTurn = false;
      int aiCell = tttAiMove();
      if (aiCell >= 0) tttBoard[aiCell] = 'O';
      char w2 = tttCheckWinner();
      if (w2 == 'O') {
        tttResult = "robot";
        playFaceSound(FACE_SAD);
      } else if (w2 == 'D') {
        tttResult = "draw";
      }
      tttPlayerTurn = true;
    }
    msg = (tttResult != "") ? "Game over" : "OK";
  }
  drawTttBoard();

  StaticJsonDocument<128> res;
  res["ok"] = true;
  res["message"] = msg;
  res["result"] = tttResult;
  String out;
  serializeJson(res, out);
  server.send(200, "application/json", out);
}

void handleTttStop() {
  addCORS();
  tttActive = false;
  registerActivity();
  drawFace(currentFace);
  server.send(200, "application/json", "{\"ok\":true,\"message\":\"Game closed\"}");
}
