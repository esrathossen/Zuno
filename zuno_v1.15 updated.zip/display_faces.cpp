// =========================================================
// display_faces.cpp - everything drawn on the OLED: boot screens,
// the persistent HUD (clock/wifi/battery icon), all 8 face
// expressions, overlays (weather/temp/scan), and the radar scan
// animation.
// =========================================================
#include "globals.h"

// ---------------- FACE / OLED ----------------

// "Zuno" splash screen shown once at boot, before the WiFi connect attempt.
void showBootLogo() {
  display.clearDisplay();
  display.setTextColor(SH110X_WHITE);
  display.setTextSize(3);
  display.setCursor(28, 20);   // Centered
  display.print("Zuno");
  display.display();
  delay(1800);
}

// Friendly greeting shown right after the boot logo, before the robot
// settles into WiFi connect + its normal face.
void showBootGreeting() {
  display.clearDisplay();
  display.setTextColor(SH110X_WHITE);
  drawCenteredText("Hi!", 14, 3);
  drawCenteredText("I'm Zuno", 46, 1);
  display.display();
  delay(1500);
}

// Signal-bar WiFi icon, top-right corner. Filled bars = connected,
// outline-only bars = not connected.
void drawWifiIcon(bool connected) {
  int baseX = 109, baseY = 6;
  int barW = 3, gap = 2;
  int heights[4] = {1, 2, 3, 4};
  for (int i = 0; i < 4; i++) {
    int x = baseX + i * (barW + gap);
    int h = heights[i];
    int y = baseY - h;
    if (connected) {
      display.fillRect(x, y, barW, h, SH110X_WHITE);
    } else {
      display.drawFastHLine(baseX + 3, baseY, 12, SH110X_WHITE);
    }
  }
}

// Draws text horizontally centered at the given y (top of the glyphs),
// using the given GFX text size.
void drawCenteredText(const String &text, int y, int textSize) {
  display.setTextSize(textSize);

  int16_t x1, y1;
  uint16_t w, h;
  display.getTextBounds(text, 0, 0, &x1, &y1, &w, &h);

  int x = (128 - w) / 2;
  display.setCursor(x, y - y1);
  display.print(text);
}

// Persistent status bar: real-time clock top-left, WiFi bars top-right.
// Temp/humidity is no longer shown here continuously - tap TEMP in the
// app for a large 10-second reading instead (see showTempOverlay()).
// Battery % itself is app-only (see /api/status) - the OLED only shows a
// small low-battery icon, left side just below the clock, at/below
// BATTERY_LOW_PERCENT (computeAutoFace() also forces Sleep at that point).
void drawHud() {
  display.setTextColor(SH110X_WHITE);
  display.setTextSize(1);

  drawWifiIcon(wifiConnected);

  display.setCursor(0, 0);
  display.print(getHudTimeString());

  if (lastBatteryPercent >= 0 && lastBatteryPercent <= BATTERY_LOW_PERCENT) {
    drawLowBatteryIcon(0, 11);
  }
}

// Small battery outline with a near-empty fill, used only as a low-battery
// warning icon (see drawHud()) - never shown at a normal charge level.
void drawLowBatteryIcon(int x, int y) {
  display.drawRect(x, y, 12, 7, SH110X_WHITE);        // body
  display.fillRect(x + 12, y + 2, 2, 3, SH110X_WHITE); // terminal nub
  display.fillRect(x + 1, y + 1, 2, 5, SH110X_WHITE);  // sliver of charge left
}

// Puts text on screen for durationMs, overriding the face until it expires
// (checked and reverted in loop()). Used by Weather and the Scan result.
void showOverlay(String line1, String line2, unsigned long durationMs) {
  overlayLine1 = line1;
  overlayLine2 = line2;
  overlayActive = true;
  overlayUntil = millis() + durationMs;

  display.clearDisplay();
  display.setTextColor(SH110X_WHITE);
  drawCenteredText(overlayLine1, 22, 1);
  drawCenteredText(overlayLine2, 38, 1);
  drawWifiIcon(wifiConnected);
  display.display();
}

// Big single-line "32.5C - 90%" reading from the DHT22, text size 2,
// shown for 10 seconds. Only ever called when no other overlay is active
// (see the show_temp command handler), so it can't collide with Weather
// or the Scan screen.
void showTempOverlay() {
  char buf[24];
  if (isnan(lastTemp) || isnan(lastHum)) {
    snprintf(buf, sizeof(buf), "--C - --%%");
  } else {
    snprintf(buf, sizeof(buf), "%.1fC - %.0f%%", lastTemp, lastHum);
  }
  overlayLine1 = String(buf);
  overlayLine2 = "";
  overlayActive = true;
  overlayUntil = millis() + 10000; // 10 seconds

  display.clearDisplay();
  display.setTextColor(SH110X_WHITE);
  drawCenteredText(overlayLine1, 24, 2); // vertically centered for a size-2 line
  drawWifiIcon(wifiConnected);
  display.display();
}

// One frame of the radar sweep shown during a manual Scan: a half-circle
// dome with a sweeping line at the current servo angle, and a blip if
// something was detected within range.
void drawRadarFrame(int angleDeg, long distanceCm) {
  display.clearDisplay();

  int cx = 64, cy = 60;
  int maxR = 46;

  for (int r = 15; r <= maxR; r += 15) {
    for (int a = 0; a <= 180; a += 4) {
      float rad = radians((float)a);
      int x = cx + (int)(r * cos(rad));
      int y = cy - (int)(r * sin(rad));
      display.drawPixel(x, y, SH110X_WHITE);
    }
  }
  display.drawLine(cx - maxR, cy, cx + maxR, cy, SH110X_WHITE);

  float rad = radians((float)angleDeg);
  int sx = cx + (int)(maxR * cos(rad));
  int sy = cy - (int)(maxR * sin(rad));
  display.drawLine(cx, cy, sx, sy, SH110X_WHITE);

  if (distanceCm > 0 && distanceCm < 100) {
    int br = map(distanceCm, 0, 100, 6, maxR);
    int bx = cx + (int)(br * cos(rad));
    int by = cy - (int)(br * sin(rad));
    display.fillCircle(bx, by, 2, SH110X_WHITE);
  }

  display.setTextSize(1);
  display.setTextColor(SH110X_WHITE);
  display.setCursor(2, 0);
  display.print("SCANNING");

  display.display();
}

void showScanStatusScreen(long left, long right) {
  display.clearDisplay();
  display.setTextColor(SH110X_WHITE);
  display.setTextSize(1);
  display.setCursor(14, 8);
  display.print("SCAN COMPLETE");
  display.setCursor(6, 30);
  display.print("Left:  ");
  display.print(left);
  display.print(" cm");
  display.setCursor(6, 46);
  display.print("Right: ");
  display.print(right);
  display.print(" cm");
  drawWifiIcon(wifiConnected);
  display.display();
}

// Wrapper around drawFace() that remembers the selected expression so
// handleBlinking() can restore it after a blink.
// Called by the face_* API commands (no longer exposed as buttons in the
// app): shows the picked face immediately and keeps it for
// MANUAL_FACE_DURATION, after which the automatic face logic resumes.
void setManualOverrideFace(FaceType f) {
  manualOverrideActive = true;
  manualOverrideFace = f;
  manualOverrideUntil = millis() + MANUAL_FACE_DURATION;
  currentFace = f;
  if (!overlayActive) drawFace(f);
}

void handleBlinking() {
  if (overlayActive) return;
  if (millis() - blinkTimer > 3000) {
    blinkTimer = millis();
    drawFace(FACE_BLINK);
    delay(120);
    drawFace(currentFace); // restore the selected expression
  }
}

// Adafruit GFX has no native ellipse fill, so this scans row by row
void fillEllipse(int cx, int cy, int rx, int ry) {
  for (int dy = -ry; dy <= ry; dy++) {
    int dx = (int)(rx * sqrt(1.0 - ((float)(dy * dy) / (float)(ry * ry))));
    display.drawFastHLine(cx - dx, cy + dy, 2 * dx + 1, SH110X_WHITE);
  }
}

// "Happy" half circle-shaped eye
void drawHappyEye(int cx, int cy, int r) {
  for (int y= -r; y <=0; y++) {
    int x = sqrt(r * r - y * y);
    display.drawFastHLine(cx - x, cy + y, 2 * x + 1, SH110X_WHITE);
  }
}

// "Sad" eye: domed bottom + pointed top (teardrop pointing up - drooping look)
void drawSadEye(int cx, int cy, int rx, int ry, bool isLeftEye) {
  // Draw the normal eye
  fillEllipse(cx, cy, rx, ry);

  if (isLeftEye) {
    // Left eye: droops toward the center
    display.fillTriangle(
      cx - rx - 2, cy - ry - 2,
      cx + rx + 2, cy - ry + 6,
      cx + rx + 2, cy - ry - 2,
      SH110X_BLACK
    );
  } else {
    // Right eye: mirror image
    display.fillTriangle(
      cx - rx - 2, cy - ry + 6,
      cx - rx - 2, cy - ry - 2,
      cx + rx + 2, cy - ry - 2,
      SH110X_BLACK
    );
  }
}

// Angry eye: triangle with the inner corner pointing down toward center
void drawAngryEye(int cx, int cy, int r, bool isLeftEye) {
  if (isLeftEye) {
    display.fillTriangle(cx - r, cy - r, cx + r, cy + 2, cx - r, cy + r, SH110X_WHITE);
  } else {
    display.fillTriangle(cx + r, cy - r, cx - r, cy + 2, cx + r, cy + r, SH110X_WHITE);
  }
}

// Small heart shape used for the Love face's eyes
void drawHeart(int cx, int cy, int r) {
  display.fillCircle(cx - r / 2, cy, r / 2, SH110X_WHITE);
  display.fillCircle(cx + r / 2, cy, r / 2, SH110X_WHITE);
  display.fillTriangle(cx - r, cy, cx + r, cy, cx, cy + r, SH110X_WHITE);
}


void drawFace(FaceType face) {
  display.clearDisplay();

  // Face area sits below the HUD (which occupies roughly y=0-33)
  int leftX = 42, rightX = 86, eyeY = 40;

  switch (face) {
    case FACE_NORMAL:
      fillEllipse(leftX + normalEyeOffsetX, eyeY + normalEyeOffsetY, 13, 16);
      fillEllipse(rightX + normalEyeOffsetX, eyeY + normalEyeOffsetY, 13, 16);
      break;

    case FACE_HAPPY:
      drawHappyEye(leftX, eyeY, 14);
      drawHappyEye(rightX, eyeY, 14);
      break;

    case FACE_ANGRY:
      drawAngryEye(leftX, eyeY, 15, true);
      drawAngryEye(rightX, eyeY, 15, false);
      break;

    case FACE_SLEEP:
      display.drawFastHLine(leftX - 14, eyeY, 28, SH110X_WHITE);
      display.drawFastHLine(rightX - 14, eyeY, 28, SH110X_WHITE);
      display.setTextColor(SH110X_WHITE);
      display.setTextSize(1);
      display.setCursor(80, 16);
      display.print("z");

      display.setCursor(90, 12);
      display.print("Z");
      break;

    case FACE_LOVE:
      drawHeart(leftX, eyeY, 13);
      drawHeart(rightX, eyeY, 13);
      break;

    case FACE_SAD:
      drawSadEye(leftX, eyeY +15, 13, 16, true);
      drawSadEye(rightX, eyeY +15, 13, 16, false);
      break;

    case FACE_SURPRISED:
      fillEllipse(leftX, eyeY, 18, 18);
      fillEllipse(rightX, eyeY, 18, 18);
      break;

    case FACE_BLINK:
    display.drawFastHLine(leftX - 14, eyeY, 28, SH110X_WHITE);
    display.drawFastHLine(rightX - 14, eyeY, 28, SH110X_WHITE);
    break;
  }

  drawHud();
  display.display();
}

// Deliberate "searching" look, drawn during the SCANNING servo sweep -
// eyes shifted toward the direction the servo is currently pointing, so
// the face visually tracks the physical scan (offsetX<0 = looking left,
// >0 = looking right, 0 = center).
void drawLookAroundFace(int offsetX) {
  display.clearDisplay();
  int leftX = 42, rightX = 86, eyeY = 40;
  fillEllipse(leftX + offsetX, eyeY, 13, 16);
  fillEllipse(rightX + offsetX, eyeY, 13, 16);
  drawHud();
  display.display();
}
