// =========================================================
// motion.cpp - motors, ultrasonic distance sensor, obstacle scan,
// DHT22 temp/humidity, battery voltage reading, and the Catch Me
// game's movement logic.
// =========================================================
#include "globals.h"

// Catch Me game: wanders around evading with basic obstacle avoidance,
// "caught" once something stays within CATCH_DISTANCE_CM for CATCH_GRACE_MS
// (i.e. a hand closing in on the sensor).
void handleCatchMe(long distance) {
  if (catchState != CATCH_RUNNING) { stopCar(); return; }

  if (distance > 0 && distance < CATCH_DISTANCE_CM) {
    if (catchCloseSince == 0) catchCloseSince = millis();
    if (millis() - catchCloseSince >= CATCH_GRACE_MS) {
      stopCar();
      catchState = CATCH_CAUGHT;
      catchCaughtElapsedMs = millis() - catchStartTime;
      setManualOverrideFace(FACE_SURPRISED);
      playFaceSound(FACE_SURPRISED);
    }
    return;
  }
  catchCloseSince = 0;

  if (distance > 0 && distance < STOP_DISTANCE_CM) {
    // Obstacle/wall, not necessarily a hand - quick dodge and re-roll evasive move.
    stopCar();
    turnLeft(SELF_DRIVE_SPEED);
    delay(300);
    stopCar();
    lastEvadeChange = 0; // force a fresh move choice below
  }

  if (millis() - lastEvadeChange >= EVADE_INTERVAL_MS) {
    lastEvadeChange = millis();
    int r = random(0, 4);
    if (r == 0)      driveForward(SELF_DRIVE_SPEED);
    else if (r == 1) turnLeft(SELF_DRIVE_SPEED);
    else if (r == 2) turnRight(SELF_DRIVE_SPEED);
    else             driveBackward(SELF_DRIVE_SLOW_SPEED);
  }
}

// ---------------- MOTOR CONTROL ----------------
void driveForward(int speed) {
  digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW);
  digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW);
  analogWrite(ENA, speed);
  analogWrite(ENB, speed);
}

void driveBackward(int speed) {
  digitalWrite(IN1, LOW); digitalWrite(IN2, HIGH);
  digitalWrite(IN3, LOW); digitalWrite(IN4, HIGH);
  analogWrite(ENA, speed);
  analogWrite(ENB, speed);
}

void turnLeft(int speed) {
  digitalWrite(IN1, LOW); digitalWrite(IN2, HIGH);
  digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW);
  analogWrite(ENA, speed);
  analogWrite(ENB, speed);
}

void turnRight(int speed) {
  digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW); digitalWrite(IN4, HIGH);
  analogWrite(ENA, speed);
  analogWrite(ENB, speed);
}

void stopCar() {
  digitalWrite(IN1, LOW); digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW); digitalWrite(IN4, LOW);
  analogWrite(ENA, 0);
  analogWrite(ENB, 0);
}

// ---------------- ULTRASONIC ----------------
long getDistanceCM() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 25000); // 25ms timeout (~4m)
  if (duration == 0) return -1; // no echo / out of range
  return duration * 0.0343 / 2;
}

int lookAndMeasure(int angle) {
  scanServo.write(angle);
  delay(350); // let servo settle
  return getDistanceCM();
}

// Used by the app's "Scan" button: sweeps the servo end-to-end, drawing a
// radar animation on the OLED, then shows a result screen for a moment.
void performScan() {
  stopCar();
  overlayActive = true; // block face/HUD redraws for the whole sweep+result

  lastScanLeft = -1;
  lastScanRight = -1;

  for (int angle = 160; angle >= 20; angle -= 20) {
    scanServo.write(angle);
    delay(150);
    long d = getDistanceCM();
    drawRadarFrame(angle, d);
    if (angle == 160) lastScanLeft = d;
    if (angle == 20)  lastScanRight = d;
  }
  scanServo.write(90);
  delay(150);

  showScanStatusScreen(lastScanLeft, lastScanRight);
  delay(1500);

  overlayActive = false;
  drawFace(currentFace);
}

// ---------------- DHT22 ----------------
void handleDHT() {
  if (millis() - lastDHTRead < DHT_READ_INTERVAL) return;
  lastDHTRead = millis();

  float h = dht.readHumidity();
  float t = dht.readTemperature();
  if (!isnan(h) && !isnan(t)) {
    lastTemp = t;
    lastHum = h;
  }
}

// ---------------- BATTERY ----------------
// Shown only in the web app (see /api/status battery_v / battery_pct).
// The OLED stays silent about it except for a small low-battery icon and
// forcing the Sleep face once it drops to/below BATTERY_LOW_PERCENT.
void readBattery() {
  if (millis() - lastBatteryRead < BATTERY_READ_INTERVAL) return;
  lastBatteryRead = millis();

  int raw = analogRead(BATTERY_PIN);
  float adcVoltage = (raw / (float)BATTERY_ADC_MAX) * BATTERY_ADC_VREF;
  lastBatteryVoltage = adcVoltage * BATTERY_DIVIDER_RATIO;

  float pct = (lastBatteryVoltage - BATTERY_MIN_V) / (BATTERY_MAX_V - BATTERY_MIN_V) * 100.0;
  lastBatteryPercent = constrain((int)pct, 0, 100);
}
