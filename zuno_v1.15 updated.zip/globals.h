#pragma once
// =========================================================
// globals.h - shared pins, tunables, enums, state, and function
// prototypes used across all .cpp modules of the Zuno robot car.
//
// Every module (.cpp file) includes this header so it can see the
// shared state/objects/functions. Only zuno_v1_15.ino actually
// DEFINES the global variables and objects (see "extern" below) -
// every other file just references them.
// =========================================================

#include <Wire.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ESPmDNS.h>
#include <ArduinoJson.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>     // [OLED DRIVER] swap for <Adafruit_SSD1306.h> if using SSD1306
#include <ESP32Servo.h>
#include <DHT.h>

// ---------------- WIFI FALLBACK DEFAULTS ----------------
extern const char* WIFI_SSID;
extern const char* WIFI_PASSWORD;

// ---------------- PIN CONFIG (classic ESP32 DevKitC) ----------------
#define OLED_SDA      21
#define OLED_SCL      22
#define OLED_ADDR     0x3C

#define TRIG_PIN      27
#define ECHO_PIN      34   // input-only pin - fine for ECHO, don't use for outputs

#define SERVO_PIN     13

#define DHT_PIN       32
#define DHT_TYPE      DHT22

#define IN1 25
#define IN2 26
#define IN3 17
#define IN4 16
#define ENA 18
#define ENB 19

#define BATTERY_PIN   35   // ADC1 input-only pin, from the voltage sensor module's signal (S) output
#define BUZZER_PIN 4

// ---------------- TUNABLE PARAMS ----------------
const int   STOP_DISTANCE_CM   = 20;   // stop & scan below this (self-driving only)
const int   SLOW_DISTANCE_CM   = 40;   // slow down below this (self-driving only)
const int   SELF_DRIVE_SPEED      = 90;  // 0-255
const int   SELF_DRIVE_SLOW_SPEED = 50;  // 0-255
const int   MANUAL_SPEED           = 90; // 0-255, used by the app's D-pad
const unsigned long DHT_READ_INTERVAL = 4000;
const unsigned long WIFI_CHECK_INTERVAL = 5000;
const unsigned long HUD_REFRESH_INTERVAL = 1000; // how often the clock/temp HUD redraws
const unsigned long BATTERY_READ_INTERVAL = 5000;

// 2S Li-ion pack (2x 18650): 3.0V/cell empty, 4.2V/cell full.
const float BATTERY_MIN_V = 6.0;
const float BATTERY_MAX_V = 8.4;
const float BATTERY_DIVIDER_RATIO = 5.0;
const float BATTERY_ADC_VREF = 3.3;
const int   BATTERY_ADC_MAX = 4095;
const int   BATTERY_LOW_PERCENT = 20; // OLED low-battery icon + forced Sleep face at/below this

// Idle "look around" eye animation for the Normal face - picks a new small
// eye offset every LOOK_AROUND_MIN..MAX_MS while Normal is on screen.
const unsigned long LOOK_AROUND_MIN_MS = 1500;
const unsigned long LOOK_AROUND_MAX_MS = 3500;

// A face picked via the API overrides the automatic mode-based face for
// 10 seconds, then automatic logic resumes.
const unsigned long MANUAL_FACE_DURATION = 10000;

// Idle "personality" cycle timings.
const unsigned long IDLE_NORMAL_MS = 30000; // 30s showing Normal
const unsigned long IDLE_RANDOM_MS = 5000;  //  5s flashing a random emotion

// Scan button cooldown - stops rapid double-taps from queuing up
// back-to-back servo sweeps.
const unsigned long SCAN_COOLDOWN = 5000; // 5s between scans

// Self Driving safety timeout.
const unsigned long SELF_DRIVE_AUTO_STOP = 3UL * 60UL * 1000UL; // 3 minutes

// Catch Me game tuning.
const int   CATCH_DISTANCE_CM   = 8;
const unsigned long CATCH_GRACE_MS    = 400;
const unsigned long EVADE_INTERVAL_MS = 900;

// ---------------- ENUMS / STRUCTS ----------------
enum RobotState { DRIVING, SLOWING, SCANNING };
enum OperatingMode { MODE_SELF_DRIVE, MODE_STILL, MODE_MANUAL, MODE_CATCH_ME };
enum FaceType { FACE_NORMAL, FACE_HAPPY, FACE_ANGRY, FACE_SLEEP, FACE_LOVE, FACE_SAD, FACE_SURPRISED, FACE_BLINK };
enum CatchState { CATCH_IDLE, CATCH_RUNNING, CATCH_CAUGHT };

struct SoundStep { int freq; unsigned long durationMs; };

// ---------------- SHARED OBJECTS (defined once in the .ino) ----------------
extern Adafruit_SH1106G display;   // [OLED DRIVER] extern Adafruit_SSD1306 display;
extern Servo scanServo;
extern DHT dht;
extern WebServer server;
extern Preferences prefs;

// ---------------- SHARED STATE (defined once in the .ino) ----------------
extern RobotState state;
extern OperatingMode currentMode;
extern FaceType currentFace;

extern bool manualOverrideActive;
extern FaceType manualOverrideFace;
extern unsigned long manualOverrideUntil;

extern unsigned long idleCycleStart;
extern bool idleInRandomPhase;
extern FaceType idleRandomFace;
extern unsigned long lastCommandTime;

extern unsigned long lastScanTime;

extern unsigned long selfDriveSince;
extern bool forceSleepAfterAutoStop;

extern SoundStep soundQueue[4];
extern int soundQueueLen;
extern int soundStepIndex;
extern unsigned long soundStepUntil;

extern bool tttActive;
extern char tttBoard[9];
extern bool tttPlayerTurn;
extern String tttResult;

extern float gmtOffsetHours;
extern float defaultWeatherLat;
extern float defaultWeatherLon;

extern unsigned long lastDHTRead;
extern bool wifiConnected;
extern bool isAPMode;
extern String currentSSID;
extern unsigned long lastWifiCheck;
extern float lastTemp, lastHum;
extern long lastDistance;
extern long lastScanLeft, lastScanRight;

extern bool timeSynced;
extern bool weatherSynced;
extern float weatherTemp;
extern String weatherDesc;

extern unsigned long lastBatteryRead;
extern float lastBatteryVoltage;
extern int lastBatteryPercent;

extern CatchState catchState;
extern unsigned long catchStartTime;
extern unsigned long catchCaughtElapsedMs;
extern unsigned long catchCloseSince;
extern unsigned long lastEvadeChange;

extern int normalEyeOffsetX;
extern int normalEyeOffsetY;
extern unsigned long nextLookChange;

extern unsigned long blinkTimer;
extern unsigned long lastHudRefresh;
extern bool objectDetected;
extern bool pathObstacleDetected;

extern bool overlayActive;
extern unsigned long overlayUntil;
extern String overlayLine1, overlayLine2;

// ---------------- FUNCTION PROTOTYPES ----------------
// motion.cpp
void handleCatchMe(long distance);
void driveForward(int speed);
void driveBackward(int speed);
void turnLeft(int speed);
void turnRight(int speed);
void stopCar();
long getDistanceCM();
int lookAndMeasure(int angle);
void performScan();
void handleDHT();
void readBattery();

// sound_games.cpp
void queueSound(const SoundStep* steps, int len);
void handleBuzzer();
void playFaceSound(FaceType f);
int tttAiMove();
void drawTttBoard();
void handleTttStart();
void handleTttMove();
void handleTttStop();

// network.cpp
void connectWiFi();
void handleWiFiStatus();
String getTimeString();
String getHudTimeString();
String wmoToDesc(int code);
bool fetchWeather(float lat, float lon);
void addCORS();
void handleRoot();
String modeToString(OperatingMode m);
FaceType computeAutoFace();
FaceType computeIdleCycleFace();
void registerActivity();
void handleIdleLookAround();
String faceToString(FaceType f);
void handleStatus();
void handleCommand();
void handleWifiSet();
void handleWeatherSync();
void handleWifiReset();
void handleGetSettings();
void handleSetSettings();
void setupServer();

// display_faces.cpp
void showBootLogo();
void showBootGreeting();
void drawWifiIcon(bool connected);
void drawCenteredText(const String &text, int y, int textSize);
void drawHud();
void drawLowBatteryIcon(int x, int y);
void showOverlay(String line1, String line2, unsigned long durationMs);
void showTempOverlay();
void drawRadarFrame(int angleDeg, long distanceCm);
void showScanStatusScreen(long left, long right);
void setManualOverrideFace(FaceType f);
void handleBlinking();
void fillEllipse(int cx, int cy, int rx, int ry);
void drawHappyEye(int cx, int cy, int r);
void drawSadEye(int cx, int cy, int rx, int ry, bool isLeftEye);
void drawAngryEye(int cx, int cy, int r, bool isLeftEye);
void drawHeart(int cx, int cy, int r);
void drawFace(FaceType face);
void drawLookAroundFace(int offsetX);
