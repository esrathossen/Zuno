// =========================================================
// network.cpp - WiFi connection, time/NTP, weather (Open-Meteo),
// the web server's API routes, settings persistence, and the
// mode/idle-face logic that decides what expression to show.
// =========================================================
#include "globals.h"
#include "web_ui.h"

// ---------------- WIFI ----------------
void connectWiFi() {
  prefs.begin("robot", false);
  String ssid = prefs.getString("ssid", WIFI_SSID);
  String pass = prefs.getString("pass", WIFI_PASSWORD);
  gmtOffsetHours   = prefs.getFloat("gmt_offset", 6.0);
  defaultWeatherLat = prefs.getFloat("def_lat", 23.8103);
  defaultWeatherLon = prefs.getFloat("def_lon", 90.4125);

  if (ssid.length() > 0 && ssid != "YOUR_WIFI_NAME") {
    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid.c_str(), pass.c_str());
    Serial.print("Connecting to WiFi");
    unsigned long start = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - start < 10000) {
      Serial.print(".");
      delay(300);
    }
    Serial.println();
  }

  if (WiFi.status() == WL_CONNECTED) {
    wifiConnected = true;
    isAPMode = false;
    currentSSID = ssid;
    Serial.print("WiFi connected, IP: ");
    Serial.println(WiFi.localIP());
    if (MDNS.begin("robotcar")) {
      Serial.println("mDNS ready: try http://robotcar.local/");
    }
    configTime((long)(gmtOffsetHours * 3600), 0, "pool.ntp.org", "time.google.com"); // configurable via app Settings
  } else {
    Serial.println("Could not join saved WiFi. Starting setup hotspot.");
    WiFi.mode(WIFI_AP);
    WiFi.softAP("RobotCar-Setup", "12345678");
    isAPMode = true;
    wifiConnected = false;
    currentSSID = "";
    Serial.print("AP IP: ");
    Serial.println(WiFi.softAPIP());
  }
}

void handleWiFiStatus() {
  if (millis() - lastWifiCheck < WIFI_CHECK_INTERVAL) return;
  lastWifiCheck = millis();
  if (!isAPMode) {
    wifiConnected = (WiFi.status() == WL_CONNECTED);
  }
}

// ---------------- TIME ----------------
// Full timestamp for the /api/status card.
String getTimeString() {
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo, 100)) return "Not synced";
  timeSynced = true;
  char buf[24];
  strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &timeinfo);
  return String(buf);
}

// Short "HH:MM" used in the persistent OLED HUD.
String getHudTimeString() {
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo, 50)) return "--:--";
  timeSynced = true;
  char buf[6];
  strftime(buf, sizeof(buf), "%H:%M", &timeinfo);
  return String(buf);
}

// ---------------- WEATHER ----------------
String wmoToDesc(int code) {
  if (code == 0) return "Clear sky";
  if (code <= 3) return "Partly cloudy";
  if (code == 45 || code == 48) return "Fog";
  if (code >= 51 && code <= 57) return "Drizzle";
  if (code >= 61 && code <= 67) return "Rain";
  if (code >= 71 && code <= 77) return "Snow";
  if (code >= 80 && code <= 82) return "Rain showers";
  if (code >= 95) return "Thunderstorm";
  return "Unknown";
}

bool fetchWeather(float lat, float lon) {
  if (!wifiConnected) return false;

  WiFiClientSecure client;
  client.setInsecure(); // skip cert validation - fine for a hobby project
  HTTPClient https;
  String url = "https://api.open-meteo.com/v1/forecast?latitude=" + String(lat, 4) +
               "&longitude=" + String(lon, 4) + "&current_weather=true";

  bool ok = false;
  if (https.begin(client, url)) {
    int code = https.GET();
    if (code == 200) {
      String payload = https.getString();
      StaticJsonDocument<1024> wdoc;
      if (!deserializeJson(wdoc, payload)) {
        weatherTemp = wdoc["current_weather"]["temperature"] | NAN;
        int wcode = wdoc["current_weather"]["weathercode"] | -1;
        weatherDesc = wmoToDesc(wcode);
        weatherSynced = true;
        ok = true;
      }
    }
    https.end();
  }
  return ok;
}

// ---------------- WEB SERVER ----------------
void addCORS() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
}

void handleRoot() {
  server.sendHeader("Cache-Control", "no-store, no-cache, must-revalidate");
  server.send(200, "text/html", INDEX_HTML);
}

String modeToString(OperatingMode m) {
  if (m == MODE_SELF_DRIVE) return "self_driving";
  if (m == MODE_MANUAL) return "manual";
  if (m == MODE_CATCH_ME) return "catch_me";
  return "still";
}

// Automatic face for the current mode/state, used whenever no manual
// override is active. Low battery takes priority over everything else.
FaceType computeAutoFace() {
  if (lastBatteryPercent >= 0 && lastBatteryPercent <= BATTERY_LOW_PERCENT) {
    return FACE_SLEEP; // battery protection - always wins, regardless of mode
  }

  if (currentMode == MODE_SELF_DRIVE) {
    if (objectDetected) return FACE_SAD;         // actually stopped for an obstacle
    if (pathObstacleDetected) return FACE_ANGRY;  // obstacle detected in path, still moving/slowing
    return computeIdleCycleFace();                // clear path - idle personality cycle
  } else if (currentMode == MODE_CATCH_ME) {
    return (catchState == CATCH_CAUGHT) ? FACE_SURPRISED : FACE_HAPPY;
  }

  if (forceSleepAfterAutoStop) return FACE_SLEEP; // just auto-stopped from a 3-min Self Driving run
  return computeIdleCycleFace(); // MODE_STILL and MODE_MANUAL: same idle personality cycle
}

// Idle personality cycle, shared by Self Driving (when clear), Still, and
// Manual: mostly Normal (with the look-around animation) for
// IDLE_NORMAL_MS, then a brief random emotion for IDLE_RANDOM_MS, on
// repeat. The random face is rolled once per entry into the random phase
// (not every call) so it holds steady for the full 5s window.
FaceType computeIdleCycleFace() {
  unsigned long cycleLen = IDLE_NORMAL_MS + IDLE_RANDOM_MS;
  unsigned long cyclePos = (millis() - idleCycleStart) % cycleLen;
  bool nowRandomPhase = (cyclePos >= IDLE_NORMAL_MS);

  if (nowRandomPhase && !idleInRandomPhase) {
    const FaceType options[] = { FACE_HAPPY, FACE_ANGRY, FACE_LOVE, FACE_SURPRISED, FACE_SAD };
    idleRandomFace = options[random(0, 5)];
  }
  idleInRandomPhase = nowRandomPhase;
  return nowRandomPhase ? idleRandomFace : FACE_NORMAL;
}

// Called whenever the robot receives any command from the app. Restarts
// the idle personality cycle fresh at Normal, and clears the "just
// auto-stopped from Self Driving" Sleep override.
void registerActivity() {
  lastCommandTime = millis();
  idleCycleStart = millis();
  idleInRandomPhase = false;
  forceSleepAfterAutoStop = false;
}

// While the Normal face is idle on screen, periodically nudges the eyes
// to a new small offset (or back to center) so the robot looks like it's
// glancing around by itself instead of just staring blankly. Harmless to
// run even when a different face is showing - drawFace() only applies
// this offset in the FACE_NORMAL case.
void handleIdleLookAround() {
  if (millis() < nextLookChange) return;
  nextLookChange = millis() + random(LOOK_AROUND_MIN_MS, LOOK_AROUND_MAX_MS);

  int r = random(0, 5); // weight one option toward "look straight ahead"
  if (r == 0) {
    normalEyeOffsetX = 0;
    normalEyeOffsetY = 0;
  } else {
    normalEyeOffsetX = random(-4, 5); // -4..4 px
    normalEyeOffsetY = random(-2, 3); // -2..2 px
  }
}

String faceToString(FaceType f) {
  switch (f) {
    case FACE_HAPPY:     return "happy";
    case FACE_ANGRY:     return "angry";
    case FACE_SLEEP:     return "sleep";
    case FACE_LOVE:      return "love";
    case FACE_SAD:       return "sad";
    case FACE_SURPRISED: return "surprised";
    default:             return "normal";
  }
}

void handleStatus() {
  addCORS();
  StaticJsonDocument<768> doc;
  doc["mode"] = modeToString(currentMode);
  doc["face"] = faceToString(currentFace);
  doc["distance_cm"] = lastDistance;
  doc["temp_c"] = lastTemp;
  doc["humidity"] = lastHum;
  doc["wifi_connected"] = wifiConnected;
  doc["ap_mode"] = isAPMode;
  doc["ip"] = isAPMode ? WiFi.softAPIP().toString() : WiFi.localIP().toString();
  doc["ssid"] = currentSSID;
  doc["time"] = getTimeString();
  doc["time_synced"] = timeSynced;
  doc["battery_v"] = lastBatteryVoltage;
  doc["battery_pct"] = lastBatteryPercent;
  JsonObject w = doc.createNestedObject("weather");
  w["synced"] = weatherSynced;
  w["temp_c"] = weatherTemp;
  w["desc"] = weatherDesc;

  JsonObject c = doc.createNestedObject("catch_me");
  if (catchState == CATCH_IDLE) {
    c["state"] = "idle";
  } else if (catchState == CATCH_RUNNING) {
    c["state"] = "running";
    c["elapsed_sec"] = (millis() - catchStartTime) / 1000;
  } else {
    c["state"] = "caught";
    c["elapsed_sec"] = catchCaughtElapsedMs / 1000;
  }

  JsonObject t = doc.createNestedObject("ttt");
  t["active"] = tttActive;
  t["player_turn"] = tttPlayerTurn;
  t["result"] = tttResult;
  String boardStr = "";
  for (int i = 0; i < 9; i++) boardStr += tttBoard[i];
  t["board"] = boardStr;

  String out;
  serializeJson(doc, out);
  server.send(200, "application/json", out);
}

void handleCommand() {
  addCORS();
  if (!server.hasArg("plain")) {
    server.send(400, "application/json", "{\"ok\":false,\"message\":\"No body\"}");
    return;
  }
  StaticJsonDocument<128> doc;
  if (deserializeJson(doc, server.arg("plain"))) {
    server.send(400, "application/json", "{\"ok\":false,\"message\":\"Bad JSON\"}");
    return;
  }
  String cmd = doc["cmd"] | "";
  String msg = "OK";
  registerActivity(); // any command counts as activity - resets standby/sleep timers, rerolls idle face

  // ---- Modes ----
  if (cmd == "mode_self_driving") {
    currentMode = MODE_SELF_DRIVE;
    state = DRIVING;
    selfDriveSince = millis();
    catchState = CATCH_IDLE;
    msg = "Self Driving mode";
  } else if (cmd == "mode_still") {
    currentMode = MODE_STILL;
    stopCar();
    catchState = CATCH_IDLE;
    msg = "Still mode";
  } else if (cmd == "mode_manual") {
    currentMode = MODE_MANUAL;
    stopCar();
    catchState = CATCH_IDLE;
    msg = "Manual mode - use the D-pad";
  } else if (cmd == "mode_catch_me") {
    currentMode = MODE_CATCH_ME;
    catchState = CATCH_RUNNING;
    catchStartTime = millis();
    catchCloseSince = 0;
    lastEvadeChange = 0;
    msg = "Catch Me started - go get it!";

  // ---- Manual D-pad (only effective in Manual mode) ----
  } else if (cmd == "manual_forward" || cmd == "manual_backward" ||
             cmd == "manual_left" || cmd == "manual_right" || cmd == "manual_stop") {
    if (currentMode != MODE_MANUAL) {
      server.send(400, "application/json", "{\"ok\":false,\"message\":\"Switch to Manual mode first\"}");
      return;
    }
    if (cmd == "manual_forward")      { driveForward(MANUAL_SPEED);   msg = "Moving forward"; }
    else if (cmd == "manual_backward"){ driveBackward(MANUAL_SPEED);  msg = "Moving backward"; }
    else if (cmd == "manual_left")    { turnLeft(MANUAL_SPEED);       msg = "Turning left"; }
    else if (cmd == "manual_right")   { turnRight(MANUAL_SPEED);      msg = "Turning right"; }
    else                                { stopCar();                   msg = "Stopped"; }

  // ---- Face selection (no longer exposed as buttons in the app, but kept
  // available over the API - overrides the automatic face for 10s) ----
  } else if (cmd == "face_normal")     { setManualOverrideFace(FACE_NORMAL);    msg = "Face: Normal (10s)"; }
  else if (cmd == "face_happy")        { setManualOverrideFace(FACE_HAPPY);     msg = "Face: Happy (10s)"; }
  else if (cmd == "face_angry")        { setManualOverrideFace(FACE_ANGRY);     msg = "Face: Angry (10s)"; }
  else if (cmd == "face_sleep")        { setManualOverrideFace(FACE_SLEEP);     msg = "Face: Sleep (10s)"; }
  else if (cmd == "face_love")         { setManualOverrideFace(FACE_LOVE);      msg = "Face: Love (10s)"; }
  else if (cmd == "face_sad")          { setManualOverrideFace(FACE_SAD);       msg = "Face: Sad (10s)"; }
  else if (cmd == "face_surprised")    { setManualOverrideFace(FACE_SURPRISED); msg = "Face: Surprised (10s)"; }

  // ---- Show temp/humidity overlay (10s, large text) ----
  else if (cmd == "show_temp") {
    if (overlayActive) {
      msg = "Display busy, try again in a moment";
    } else {
      showTempOverlay();
      msg = "Showing temperature (10s)";
    }
  }

  // ---- Scan ----
  else if (cmd == "scan") {
    if (overlayActive) {
      msg = "Display busy, try again in a moment";
    } else if (millis() - lastScanTime < SCAN_COOLDOWN) {
      msg = "Scan cooling down, try again shortly";
    } else {
      lastScanTime = millis();
      performScan();
      msg = "Scan complete: L=" + String(lastScanLeft) + "cm  R=" + String(lastScanRight) + "cm";
    }
  } else {
    server.send(400, "application/json", "{\"ok\":false,\"message\":\"Unknown command\"}");
    return;
  }

  StaticJsonDocument<256> res;
  res["ok"] = true;
  res["message"] = msg;
  String out;
  serializeJson(res, out);
  server.send(200, "application/json", out);
}

void handleWifiSet() {
  addCORS();
  if (!server.hasArg("plain")) {
    server.send(400, "application/json", "{\"ok\":false,\"message\":\"No body\"}");
    return;
  }
  StaticJsonDocument<256> doc;
  if (deserializeJson(doc, server.arg("plain"))) {
    server.send(400, "application/json", "{\"ok\":false,\"message\":\"Bad JSON\"}");
    return;
  }
  String ssid = doc["ssid"] | "";
  String pass = doc["password"] | "";
  if (ssid.length() == 0) {
    server.send(400, "application/json", "{\"ok\":false,\"message\":\"SSID required\"}");
    return;
  }

  prefs.putString("ssid", ssid);
  prefs.putString("pass", pass);

  server.send(200, "application/json", "{\"ok\":true,\"message\":\"Saved. Robot is rebooting to connect...\"}");
  delay(800);
  ESP.restart();
}

void handleWeatherSync() {
  addCORS();
  if (!server.hasArg("plain")) {
    server.send(400, "application/json", "{\"ok\":false,\"message\":\"No body\"}");
    return;
  }
  StaticJsonDocument<128> doc;
  if (deserializeJson(doc, server.arg("plain"))) {
    server.send(400, "application/json", "{\"ok\":false,\"message\":\"Bad JSON\"}");
    return;
  }
  float lat = doc["lat"] | defaultWeatherLat; // configurable default, used only if the phone doesn't send GPS
  float lon = doc["lon"] | defaultWeatherLon;

  bool ok = fetchWeather(lat, lon);
  String message;
  if (ok) {
    if (overlayActive) {
      // Don't interrupt a Temp overlay (or scan screen) already on screen.
      message = "Weather synced (display busy, try again)";
    } else {
      String tempStr = String(weatherTemp, 1) + " C";
      showOverlay(weatherDesc, tempStr, 6000);
      message = "Weather synced and shown on display";
    }
  } else {
    message = "Weather fetch failed (needs internet)";
  }

  StaticJsonDocument<128> res;
  res["ok"] = ok;
  res["message"] = message;
  String out;
  serializeJson(res, out);
  server.send(200, "application/json", out);
}

void handleWifiReset() {
  addCORS();
  prefs.remove("ssid");
  prefs.remove("pass");
  server.send(200, "application/json", "{\"ok\":true,\"message\":\"WiFi reset. Rebooting into setup hotspot...\"}");
  delay(800);
  ESP.restart();
}

// ---------------- SETTINGS (timezone + default weather location) ----------------
void handleGetSettings() {
  addCORS();
  StaticJsonDocument<128> doc;
  doc["gmt_offset"] = gmtOffsetHours;
  doc["lat"] = defaultWeatherLat;
  doc["lon"] = defaultWeatherLon;
  String out;
  serializeJson(doc, out);
  server.send(200, "application/json", out);
}

void handleSetSettings() {
  addCORS();
  if (!server.hasArg("plain")) {
    server.send(400, "application/json", "{\"ok\":false,\"message\":\"No body\"}");
    return;
  }
  StaticJsonDocument<256> doc;
  if (deserializeJson(doc, server.arg("plain"))) {
    server.send(400, "application/json", "{\"ok\":false,\"message\":\"Bad JSON\"}");
    return;
  }

  if (doc.containsKey("gmt_offset")) {
    gmtOffsetHours = doc["gmt_offset"] | gmtOffsetHours;
    prefs.putFloat("gmt_offset", gmtOffsetHours);
    if (wifiConnected) {
      configTime((long)(gmtOffsetHours * 3600), 0, "pool.ntp.org", "time.google.com");
    }
  }
  if (doc.containsKey("lat")) {
    defaultWeatherLat = doc["lat"] | defaultWeatherLat;
    prefs.putFloat("def_lat", defaultWeatherLat);
  }
  if (doc.containsKey("lon")) {
    defaultWeatherLon = doc["lon"] | defaultWeatherLon;
    prefs.putFloat("def_lon", defaultWeatherLon);
  }

  server.send(200, "application/json", "{\"ok\":true,\"message\":\"Settings saved\"}");
}

void setupServer() {
  server.on("/", HTTP_GET, handleRoot);
  server.on("/api/status", HTTP_GET, handleStatus);
  server.on("/api/command", HTTP_POST, handleCommand);
  server.on("/api/wifi", HTTP_POST, handleWifiSet);
  server.on("/api/wifi/reset", HTTP_POST, handleWifiReset);
  server.on("/api/weather", HTTP_POST, handleWeatherSync);
  server.on("/api/settings", HTTP_GET, handleGetSettings);
  server.on("/api/settings", HTTP_POST, handleSetSettings);
  server.on("/api/ttt/start", HTTP_POST, handleTttStart);
  server.on("/api/ttt/move", HTTP_POST, handleTttMove);
  server.on("/api/ttt/stop", HTTP_POST, handleTttStop);
  server.onNotFound([]() {
    server.send(404, "text/plain", "Not found");
  });
  server.begin();
  Serial.println("Web server started on port 80");
}
