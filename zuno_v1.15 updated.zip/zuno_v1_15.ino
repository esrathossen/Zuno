/*
  ESP32 (classic WROOM-32 DevKitC) "Zuno" Robot Car - Web App Controlled
  -----------------------------------------------------------------------
  v1.1 changes: battery voltage sensor module (web app only, small OLED
  low-battery icon + forced Sleep + motors cut at/below 20%), a unified
  idle "personality" cycle shared by Self Driving/Still/Manual (30s Normal
  with a look-around eye animation, then 5s flashing a random emotion,
  repeat), a "searching" look-around face during the Self Driving obstacle
  scan, a Catch Me evasion game, a Tic Tac Toe game played ON THE OLED with
  the app as the controller, and mood sound effects on a piezo buzzer.

  v1.2 (this file): split into modules to speed up incremental compiles.
  This .ino now only holds setup()/loop() and the global object/state
  definitions. Everything else lives in:
    globals.h          - pins, tunables, enums, extern declarations,
                          function prototypes (included by every module)
    motion.cpp          - motors, ultrasonic, DHT22, battery, Catch Me
    display_faces.cpp   - OLED HUD, faces, overlays, radar scan animation
    network.cpp         - WiFi, time/NTP, weather, web API routes, settings
    sound_games.cpp      - buzzer mood sounds, Tic Tac Toe
  Editing just one module now only recompiles that module, not the whole
  sketch - only setup()/loop() or globals.h changes force a full rebuild.

  MEMORY NOTE: this sketch is close to filling the default flash partition.
  If you get "sketch too big" at compile time, go to Tools > Partition
  Scheme and pick one with a bigger APP partition (e.g. "Huge APP (3MB No
  OTA/1MB SPIFFS)", or "Minimal SPIFFS"). Also double check Bluetooth is
  disabled in your board config if you're not using it.

  Board setting in Arduino IDE: Tools > Board > "ESP32 Dev Module"

  See globals.h for pins/tunables/enums, and the individual module files
  for feature details, wiring notes, and first-time WiFi setup.
*/

#include "globals.h"

// ---------------- WIFI FALLBACK DEFAULTS ----------------
const char* WIFI_SSID     = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// ---------------- OBJECTS ----------------
Adafruit_SH1106G display(128, 64, &Wire, -1);  // [OLED DRIVER] Adafruit_SSD1306 display(128,64,&Wire,-1);
Servo scanServo;
DHT dht(DHT_PIN, DHT_TYPE);
WebServer server(80);
Preferences prefs;

// ---------------- STATE ----------------
RobotState state = DRIVING;
OperatingMode currentMode = MODE_STILL; // boots safe
FaceType currentFace = FACE_NORMAL; // the face actually on screen right now (auto or override)

// A face picked via the API overrides the automatic mode-based face for
// 10 seconds, then automatic logic resumes. (No longer exposed as buttons
// in the app - faces in Still/Manual are automatic; see below.)
bool manualOverrideActive = false;
FaceType manualOverrideFace = FACE_NORMAL;
unsigned long manualOverrideUntil = 0;

// Idle "personality" cycle - active in all 3 driving modes whenever nothing
// more important is happening (no real obstacle event in Self Driving, no
// manual override, no low battery, no game). Mostly Normal (with the
// look-around animation), with a brief random-emotion flash every cycle.
// See computeIdleCycleFace() in network.cpp.
unsigned long idleCycleStart = 0;
bool idleInRandomPhase = false;
FaceType idleRandomFace = FACE_HAPPY;
unsigned long lastCommandTime = 0; // still used to gate registerActivity()'s cycle reset

// Scan button cooldown - stops rapid double-taps from queuing up
// back-to-back servo sweeps.
unsigned long lastScanTime = 0;

// Self Driving safety timeout: after this long continuously self-driving,
// stop and drop back to Still mode with a Sleep face until the next command.
unsigned long selfDriveSince = 0;
bool forceSleepAfterAutoStop = false;

// ---------------- BUZZER (mood sound effects) ----------------
SoundStep soundQueue[4];
int soundQueueLen = 0;
int soundStepIndex = -1; // -1 = not currently playing anything
unsigned long soundStepUntil = 0;

// ---------------- TIC TAC TOE (played on the OLED, app is the controller) ----------------
bool tttActive = false;
char tttBoard[9]; // ' ' empty, 'X' player, 'O' Zuno
bool tttPlayerTurn = true;
String tttResult = ""; // "", "player", "robot", "draw"

// Configurable from the app's Settings panel (persisted in Preferences).
// Defaults match the original hardcoded values (Dhaka, GMT+6).
float gmtOffsetHours   = 6.0;
float defaultWeatherLat = 23.8103;
float defaultWeatherLon = 90.4125;

unsigned long lastDHTRead = 0;
bool wifiConnected = false;
bool isAPMode = false;
String currentSSID = "";
unsigned long lastWifiCheck = 0;
float lastTemp = NAN, lastHum = NAN;
long lastDistance = -1;
long lastScanLeft = -1, lastScanRight = -1;

bool timeSynced = false;
bool weatherSynced = false;
float weatherTemp = NAN;
String weatherDesc = "";

// ---------------- BATTERY ----------------
unsigned long lastBatteryRead = 0;
float lastBatteryVoltage = NAN;
int lastBatteryPercent = -1; // -1 = no reading yet

// ---------------- CATCH ME GAME ----------------
CatchState catchState = CATCH_IDLE;
unsigned long catchStartTime = 0;
unsigned long catchCaughtElapsedMs = 0;
unsigned long catchCloseSince = 0;
unsigned long lastEvadeChange = 0;

// ---------------- IDLE LOOK-AROUND (Normal face) ----------------
int normalEyeOffsetX = 0;
int normalEyeOffsetY = 0;
unsigned long nextLookChange = 0;

unsigned long blinkTimer = 0;
unsigned long lastHudRefresh = 0;
bool objectDetected = false;       // true while self-driving has actually stopped for an obstacle (Sad)
bool pathObstacleDetected = false; // true while an obstacle is in path but still moving/slowing (Angry)

// Temporary OLED overlay (used by Show Weather / scan animation+status).
// While active, it takes over the screen and suppresses face/HUD redraws.
bool overlayActive = false;
unsigned long overlayUntil = 0;
String overlayLine1 = "", overlayLine2 = "";

// =========================================================
void setup() {
  Serial.begin(115200);

  Wire.begin(OLED_SDA, OLED_SCL);
  display.begin(OLED_ADDR, true);       // [OLED DRIVER] display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR);

  showBootLogo();     // clears + draws + display()s once - no need for a blank flash first
  showBootGreeting(); // brief "Hi!" greeting before the robot settles into its normal face

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);
  pinMode(ENA, OUTPUT);
  pinMode(ENB, OUTPUT);

  pinMode(BATTERY_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  // Little startup chirp (blocking here is fine - nothing else running yet)
  tone(BUZZER_PIN, 1000, 100); delay(120);
  tone(BUZZER_PIN, 1500, 150); delay(150);
  noTone(BUZZER_PIN);

  ESP32PWM::allocateTimer(0);
  scanServo.setPeriodHertz(50);
  scanServo.attach(SERVO_PIN, 500, 2400);
  scanServo.write(90); // facing forward

  dht.begin();

  connectWiFi();
  setupServer();
  randomSeed(esp_random());
  lastCommandTime = millis();
  idleCycleStart = millis();
  selfDriveSince = millis();
  readBattery(); // seed a reading immediately instead of waiting for the first interval
  memset(tttBoard, ' ', 9);

  drawFace(currentFace);
  delay(300);
}

// =========================================================
void loop() {
  server.handleClient();

  if (overlayActive && millis() > overlayUntil) {
    overlayActive = false;
    drawFace(currentFace);
  }

  // Tic Tac Toe owns the OLED entirely while a game is in progress - no
  // driving logic, no face, just wait for moves via /api/ttt/move.
  if (tttActive) {
    stopCar();
    readBattery();
    handleBuzzer();
    delay(30);
    return;
  }

  long distance = getDistanceCM();
  lastDistance = distance;

  bool batteryCritical = (lastBatteryPercent >= 0 && lastBatteryPercent <= BATTERY_LOW_PERCENT);

  if (batteryCritical) {
    // Battery protection: motors stay off in every mode until it's charged
    // back up. Face is forced to Sleep too (see computeAutoFace()).
    stopCar();
    state = DRIVING; // so self-driving resumes cleanly once charged back up
  } else if (currentMode == MODE_SELF_DRIVE && millis() - selfDriveSince >= SELF_DRIVE_AUTO_STOP) {
    // Safety timeout: after 3 continuous minutes of Self Driving, stop and
    // fall back to Still mode with a Sleep face until the next command.
    stopCar();
    currentMode = MODE_STILL;
    forceSleepAfterAutoStop = true;
  } else if (currentMode == MODE_SELF_DRIVE) {
    switch (state) {
      case DRIVING:
        if (distance > 0 && distance < STOP_DISTANCE_CM) {
          stopCar();
          objectDetected = true;       // actually stopped for an obstacle -> Sad
          pathObstacleDetected = true;
          if (!overlayActive) drawFace(FACE_SAD); // immediate feedback
          state = SCANNING;
        } else if (distance > 0 && distance < SLOW_DISTANCE_CM) {
          driveForward(SELF_DRIVE_SLOW_SPEED);
          pathObstacleDetected = true; // obstacle detected in path, still moving -> Angry
          if (!overlayActive) drawFace(FACE_ANGRY); // immediate feedback
          state = SLOWING;
        } else {
          driveForward(SELF_DRIVE_SPEED);
          pathObstacleDetected = false;
        }
        break;

      case SLOWING:
        if (distance > 0 && distance < STOP_DISTANCE_CM) {
          stopCar();
          objectDetected = true;
          if (!overlayActive) drawFace(FACE_SAD);
          state = SCANNING;
        } else if (distance >= SLOW_DISTANCE_CM || distance <= 0) {
          pathObstacleDetected = false;
          state = DRIVING;
        }
        break;

      case SCANNING: {
        stopCar();
        delay(150);

        if (!overlayActive) drawLookAroundFace(-14); // looking left, searching
        int leftDist  = lookAndMeasure(160);
        if (!overlayActive) drawLookAroundFace(14);  // looking right, searching
        int rightDist = lookAndMeasure(20);
        scanServo.write(90);
        if (!overlayActive) drawLookAroundFace(0);   // back to center, still puzzling
        delay(200);

        if (leftDist <= 0) leftDist = 0;
        if (rightDist <= 0) rightDist = 0;

        if (max(leftDist, rightDist) < STOP_DISTANCE_CM) {
          driveBackward(SELF_DRIVE_SLOW_SPEED);
          delay(500);
          stopCar();
        } else if (leftDist > rightDist) {
          turnLeft(SELF_DRIVE_SLOW_SPEED);
          delay(450);
        } else {
          turnRight(SELF_DRIVE_SLOW_SPEED);
          delay(450);
        }
        stopCar();
        objectDetected = false;
        pathObstacleDetected = false;
        state = DRIVING;
        break;
      }

      default:
        state = DRIVING;
        break;
    }
  } else if (currentMode == MODE_STILL) {
    stopCar();
  } else if (currentMode == MODE_CATCH_ME) {
    handleCatchMe(distance);
  }
  // MODE_MANUAL: no autonomous logic here - motors stay in whatever state
  // the last /api/command manual_* call put them in, until changed again.

  // Resolve which face should be showing: a manual override (from the API)
  // wins for 10 seconds, otherwise it's driven by mode/state.
  if (manualOverrideActive && millis() > manualOverrideUntil) {
    manualOverrideActive = false;
  }
  FaceType desiredFace = manualOverrideActive ? manualOverrideFace : computeAutoFace();
  bool faceChanged = (desiredFace != currentFace);
  currentFace = desiredFace;

  handleBlinking();
  handleDHT();
  handleWiFiStatus();
  readBattery();
  handleIdleLookAround();
  handleBuzzer();

  if (!overlayActive && faceChanged) {
    playFaceSound(desiredFace);
  }
  if (!overlayActive && (faceChanged || millis() - lastHudRefresh >= HUD_REFRESH_INTERVAL)) {
    lastHudRefresh = millis();
    drawFace(currentFace); // redraws face + refreshes clock/temp/humidity HUD
  }

  delay(30);
}
